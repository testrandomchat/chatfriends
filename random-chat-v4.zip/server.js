
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const multer = require('multer');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const upload = multer({ dest: 'uploads/' });

app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

io.on('connection', (socket) => {
    console.log('사용자 접속');

    // 랜덤 매칭: 대기 중인 상대 찾기
    if (!global.waiting) {
        global.waiting = socket;
    } else {
        const partner = global.waiting;
        global.waiting = null;
        socket.partner = partner;
        partner.partner = socket;

        socket.emit('matched');
        partner.emit('matched');
    }

    socket.on('message', (msg) => {
        if (socket.partner) {
            socket.partner.emit('message', msg);
        }
    });

    socket.on('disconnect', () => {
        if (socket.partner) {
            socket.partner.emit('partnerLeft');
            socket.partner.partner = null;
        } else if (global.waiting === socket) {
            global.waiting = null;
        }
    });

    socket.on('leaveRoom', () => {
        if (socket.partner) {
            socket.partner.emit('partnerLeft');
            socket.partner.partner = null;
            socket.partner = null;
        }
        if (!global.waiting) {
            global.waiting = socket;
        }
    });
});

// 사진 업로드
app.post('/upload', upload.single('image'), (req, res) => {
    res.json({ url: '/uploads/' + req.file.filename });
});

server.listen(3000, () => {
    console.log('서버 실행 중: http://localhost:3000');
});
